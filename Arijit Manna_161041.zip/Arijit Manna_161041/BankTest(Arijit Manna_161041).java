package com.cg.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.exception.AccountException;
import com.cg.exception.AmountException;
import com.cg.exception.NameException;
import com.cg.exception.PhoneNumberException;
import com.cg.service.AccountServiceImpl;

public class BankTest {
	//These comprise of the passed test cases as well as the failure test cases which have been corrected
	@Test
	public void ValidateNameTrue() throws NameException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(true, as.validateName("Arijit"));
	}
	@Test 
	public void ValidateName() throws NameException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(false, as.validateName("Arijit79"));
		assertEquals(false, as.validateName("Arijit@79"));
		assertEquals(false, as.validateName("9614376068"));
		assertEquals(false, as.validateName("arijit"));
	}
	
	@Test
	public void ValidatePhonNumberTrue() throws PhoneNumberException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(true, as.validatePhoneNumber("8001711225"));
	}
	
	@Test
	public void ValidatePhoneNumber() throws PhoneNumberException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(false, as.validatePhoneNumber("80017"));
		assertEquals(false, as.validatePhoneNumber("9614376068"));
		assertEquals(false, as.validatePhoneNumber("1234@3"));
		assertEquals(false, as.validatePhoneNumber("TestClass"));
		assertEquals(false, as.validatePhoneNumber("Mumbai@228"));
	}
	
	@Test
	public void ValidateAmountTrue() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(true, bs.validateAmount("325653"));
	}
	
	@Test 
	public void ValidateAmount() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(false, bs.validateAmount("0"));
		assertEquals(false, bs.validateAmount("-0.1"));
	}
	
	@Test
	public void ValidateAccountTrue() throws AccountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(true, bs.validateAmount("59648"));
		
	}
	@Test 
	public void ValidateAccount() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(false, bs.validateAmount("0"));
		assertEquals(false, bs.validateAmount("-12345"));
	}
	

}
